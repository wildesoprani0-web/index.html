
const menuButton=document.querySelector('.menu'),nav=document.querySelector('.nav');
if(menuButton&&nav){menuButton.addEventListener('click',()=>nav.classList.toggle('open'));nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')))}
